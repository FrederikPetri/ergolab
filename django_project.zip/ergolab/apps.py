from django.apps import AppConfig


class ErgolabConfig(AppConfig):
    name = 'ergolab'
