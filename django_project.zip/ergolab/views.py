from django.http import JsonResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Report
from . import forms
import pandas as pd

# def home(request):
#     context = {
#         'risk_reports': Report.objects.all()
#     }
#     return render(request, 'ergolab/home.html', context)


class ReportListView(LoginRequiredMixin, ListView):
    model = Report
    template_name = 'ergolab/home.html'
    context_object_name = 'risk_reports'
    paginate_by = 5

    # Only show reports that belongs to the specific author
    def get_queryset(self):
        return Report.objects.filter(author=self.request.user).order_by('-date_posted')

class ReportDetailView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    model = Report

    def test_func(self):
        report = self.get_object()

        # Test if current user is the author
        if self.request.user == report.author:
            return True
        else:
            return False

    def get_context_data(self, **kwargs):
        # Import data here

        report = self.get_object()

        context = super().get_context_data(**kwargs)
        context["qs"] = Report.objects.all()

        if len(report.rapport_1) != 0:
            risk_data_1 = pd.read_csv(report.rapport_1,header=None, sep='\n')

            # Prepare barchart data
            #barchart = risk_data_1[0][1].split(',')
            #bar_min_risk =

            context["parts_risk_1"] = risk_data_1[0][0].split(',')
            context["bar_risk_1"] = risk_data_1[0][1].split(',')

            #context["trunk_risk_1"] = risk_data_1[0][1].split(',')
            #context["arm_risk_1"] = risk_data_1[0][2].split(',')

            # Prepare linechart data
            context['line_risk_1'] = risk_data_1[0][2].split(',')

            # changes_1 = {'1': '1', '3': 'null','5': 'null','7': 'null'}
            # changes_3 = {'1': 'null', '3': '3', '5': 'null', '7': 'null'}
            # changes_5 = {'1': 'null', '3': 'null', '5': '5', '7': 'null'}
            # changes_7 = {'1': 'null', '3': 'null', '5': 'null', '7': '7'}
            #
            # linedata_1_1 = []
            # linedata_1_3 = []
            # linedata_1_5 = []
            # linedata_1_7 = []
            #
            # for i in linedata:
            #     linedata_1_1.append(changes_1[i])
            #     linedata_1_3.append(changes_3[i])
            #     linedata_1_5.append(changes_5[i])
            #     linedata_1_7.append(changes_7[i])
            #
            # context['line_risk_1_1'] = linedata_1_1
            # context['line_risk_1_3'] = linedata_1_3
            # context['line_risk_1_5'] = linedata_1_5
            # context['line_risk_1_7'] = linedata_1_7

            context['pie_risk_1'] = risk_data_1[0][3].split(',')
            context['radar_risk_1'] = risk_data_1[0][4].split(',')

        if len(report.rapport_2) != 0:
            risk_data_2 = pd.read_csv(report.rapport_2,header=None, sep='\n')

            context["parts_risk_2"] = risk_data_2[0][0].split(',')
            context["bar_risk_2"] = risk_data_2[0][1].split(',')
            #context["trunk_risk_2"] = risk_data_2[0][1].split(',')
            #context["arm_risk_2"] = risk_data_2[0][2].split(',')

            context['line_risk_2'] = risk_data_2[0][2].split(',')
            context['pie_risk_2'] = risk_data_2[0][3].split(',')
            context['radar_risk_2'] = risk_data_2[0][4].split(',')

        return context

    def get_template_names(self):
        if len(self.get_object().rapport_2) == 0:
            return ['ergolab/report_content_1.html']
        else:
            return ['ergolab/report_content_2.html']

class ReportCreateView(LoginRequiredMixin, CreateView):
    model = Report

    form_class = forms.ReportForm

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class ReportUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Report
    fields = ['titel', 'beskrivelse', 'optagelse']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    # Test if current user is the author
    def test_func(self):
        report = self.get_object()
        if self.request.user == report.author:
            return True
        return False



class ReportDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Report
    success_url = '/'

    # Test if current user is the author
    def test_func(self):
        report = self.get_object()
        if self.request.user == report.author:
            return True
        return False


def get_data(request, *args, **kwargs):
    data = {
        "neck_risk": [10, 70, 30],
        "trunk_risk": [32, 55, 31],
        "arm_risk": [12, 40, 43],
    }
    return JsonResponse(data)