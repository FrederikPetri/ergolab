from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

class Report(models.Model):
    titel = models.CharField(max_length=100)
    beskrivelse = models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    rapport_1 = models.CharField(max_length=200, default='https://raw.githubusercontent.com/FrederikPetri/ergolab/main/13-00-05-11.csv')
    rapport_2 = models.CharField(max_length=200, blank=True, default='https://raw.githubusercontent.com/FrederikPetri/ergolab/main/13-01-05-11.csv')

    class Types(models.TextChoices):
        TYPE1 = '1', "Rapport-1"
        TYPE2 = '2', "Rapport-2"

    optagelse = models.CharField(
        max_length=2,
        choices=Types.choices,
        default=Types.TYPE1
    )

    def __str__(self):
        return self.titel

    def get_absolute_url(self):
        return reverse('report-detail', kwargs={'pk': self.pk})

