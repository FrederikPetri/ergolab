from django.urls import path
from .views import ReportListView, ReportDetailView, ReportCreateView, ReportUpdateView, ReportDeleteView, get_data
from . import views

urlpatterns = [
    path('', ReportListView.as_view(), name='ergolab-home'),
    path('report/<int:pk>/', ReportDetailView.as_view(), name='report-detail'),
    path('rapport/ny/', ReportCreateView.as_view(), name='report-create'),
    path('report/<int:pk>/update/', ReportUpdateView.as_view(), name='report-update'),
    path('report/<int:pk>/delete/', ReportDeleteView.as_view(), name='report-delete'),
    #path('report/<int:pk>/print/', MyModelDownloadView.as_view(), name='report-print'),
    path('api/data/', get_data, name='api-data'),
]