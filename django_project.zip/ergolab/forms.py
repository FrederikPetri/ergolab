from django import forms
from .models import Report

class ReportForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(ReportForm, self).__init__(*args, **kwargs)
        self.fields['titel'].widget.attrs = {'class': 'title_form_class'}

    class Meta:
        model = Report

        fields = ['titel', 'beskrivelse', 'optagelse', 'rapport_1', 'rapport_2']
